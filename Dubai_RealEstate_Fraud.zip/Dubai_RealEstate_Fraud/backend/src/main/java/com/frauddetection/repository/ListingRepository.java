package com.frauddetection.repository;

import com.frauddetection.model.Listing;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ListingRepository extends JpaRepository<Listing, Long> {
    @Query("SELECT AVG(l.price) FROM Listing l WHERE l.location = :location")
    Double findAvgPriceByLocation(@Param("location") String location);
}