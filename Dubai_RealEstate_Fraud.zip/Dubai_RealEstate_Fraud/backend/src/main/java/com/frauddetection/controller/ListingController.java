package com.frauddetection.controller;

import com.frauddetection.model.Listing;
import com.frauddetection.service.FraudDetectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/listings")
public class ListingController {
    @Autowired
    private FraudDetectionService fraudService;

    @PostMapping
    public Listing addListing(@RequestBody Listing listing) {
        return fraudService.analyzeListing(listing);
    }

    @GetMapping("/potential-fraud")
    public List<Listing> getFraudListings() {
        return fraudService.getPotentialFraudListings();
    }
}