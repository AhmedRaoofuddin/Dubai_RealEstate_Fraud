package com.frauddetection.service;

import com.frauddetection.model.Listing;
import com.frauddetection.repository.ListingRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class FraudDetectionService {
    @Autowired
    private ListingRepository listingRepo;
    
    private final String AI_SERVICE_URL = "http://localhost:5001/analyze-text";

    public Listing analyzeListing(Listing listing) {
        // Check price anomaly
        Double avgPrice = listingRepo.findAvgPriceByLocation(listing.getLocation());
        if (avgPrice != null && listing.getPrice() < (avgPrice * 0.5)) {
            listing.setIsPotentialFraud(true);
        }

        // Check description with AI
        RestTemplate restTemplate = new RestTemplate();
        String description = listing.getDescription();
        Boolean isScam = restTemplate.postForObject(
            AI_SERVICE_URL,
            new DescriptionRequest(description),
            Boolean.class
        );
        
        if (isScam != null && isScam) {
            listing.setIsPotentialFraud(true);
        }

        return listingRepo.save(listing);
    }

    private static class DescriptionRequest {
        public String text;
        public DescriptionRequest(String text) { this.text = text; }
    }

    public List<Listing> getPotentialFraudListings() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getPotentialFraudListings'");
    }
}