from flask import Flask, request, jsonify
import openai
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route("/analyze-text", methods=["POST"])
def analyze_text():
    """Analyze real estate listing text for potential fraud"""
    data = request.get_json()
    
    if not data or 'text' not in data:
        return jsonify({"error": "No text provided"}), 400
    
    text = data['text'].strip()
    
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role": "system",
                    "content": "Analyze this real estate listing. Respond ONLY with 'true' if scam-like, otherwise 'false'."
                },
                {
                    "role": "user", 
                    "content": text
                }
            ],
            temperature=0.0
        )
        
        is_scam = response.choices[0].message['content'].strip().lower() == "true"
        return jsonify({"is_scam": is_scam})
        
    except Exception as e:
        print(f"AI processing error: {str(e)}")
        return jsonify({"error": "AI processing failed"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=True)